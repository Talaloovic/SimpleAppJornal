import SwiftUI

@main
struct JournalApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView() 
        }
    }
}
